# __version__ = 'some.semantic.version'
__version__ = '1.0.5'
